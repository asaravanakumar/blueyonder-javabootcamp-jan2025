package com.labs.orderapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbootOrderServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbootOrderServiceApplication.class, args);
	}

}
