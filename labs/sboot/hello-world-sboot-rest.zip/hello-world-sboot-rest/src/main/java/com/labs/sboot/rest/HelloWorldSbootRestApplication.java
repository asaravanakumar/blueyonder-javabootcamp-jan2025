package com.labs.sboot.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloWorldSbootRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloWorldSbootRestApplication.class, args);
	}

}
